//
//  APIViwelModel.swift
//  iHome
//
//  Created by Student on 30/10/23.
//

import Foundation

struct API : Decodable {
    var services: [Service]
}

struct Categoria : Decodable, Hashable {
    var tipo: String?
    var minPreco: Float?
    var maxPreco: Float?
}

struct Service : Decodable, Hashable {
    var tipo: String?
    var categorias: [Categoria]
}

struct User : Decodable, Hashable {
    
}

class APIViewModel: ObservableObject {
    
    @Published var users : [User] = []
    @Published var services : [Service] = []
    
    
//    func post(day : userDays) {
//       // let postData = PostData(title: "Example Title", body: "Example Body")
//
//        guard let encodedData = try? JSONEncoder().encode(day) else {
//            print("Failed to encode data")
//            return
//        }
//
//        guard let url = URL(string: "http://127.0.0.1:1880/notation") else {
//            print("Invalid URL")
//            return
//        }
//
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
//        request.httpBody = encodedData
//
//        URLSession.shared.dataTask(with: request) { data, response, error in
//            if let error = error {
//                print("Error: \(error.localizedDescription)")
//                return
//            }
    
    func fetch() {
        guard let url = URL(string: "http://127.0.0.1:1880/getServices") else {
            return
        }

        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data , error == nil else {return}

            do {
                let decodificado = try JSONDecoder().decode( API.self, from: data)

                DispatchQueue.main.async {
                    self?.services = decodificado.services
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
}
