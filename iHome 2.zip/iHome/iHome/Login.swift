//
//  Login.swift
//  iHome
//
//  Created by Student07 on 06/11/23.
//

import SwiftUI

struct Login: View {
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color("azul"), Color("azul")]), startPoint: .top, endPoint: .center)
                    .frame(width: .infinity, height: .infinity).ignoresSafeArea(.all)
               
                
                VStack{
                    Image("casa")
                    Text("iHome - Login")
                        .font(.title)
                        .fontWeight(.black)
                        .foregroundColor(.white)
                    
                    TextField("CPF", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/).frame(width: 300.0, height: 40.0).background(Color(#colorLiteral(red: 0, green: 0, blue: 0.7450980392, alpha: 1))).foregroundColor(.white).cornerRadius(6)
                    
                    TextField("SENHA", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/).frame(width: 300.0, height: 40.0).background(Color(#colorLiteral(red: 0, green: 0, blue: 0.7450980392, alpha: 1))).foregroundColor(.white).cornerRadius(6)
                    
                    LoginScreenButton(title: "Entrar")
                        .padding(.top)
                    
                    HStack{
                        Text("Não possui conta?").foregroundColor(.white)
                        Text("Cadastre-se").foregroundColor(.blue)
                    }  .padding(.top, 60.0)
                    
                }
                
            }

        }
    }
}

struct LoginScreenButton: View {
    var title: String
    
    var body: some View {
        HStack(alignment: .center) {
            Text(title)
                .font(.title)
                .fontWeight(.bold)
        }
        .padding()
        .background(Color(#colorLiteral(red: 0, green: 0, blue: 0.7450980392, alpha: 1)))
        .foregroundColor(.white)
        .cornerRadius(10)
        .frame(width: 900.0, height: 20.0)
        .shadow(radius: 5)
        .padding(.top, 20.0)
        .font(.caption2)
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
