//
//  AdicionarServicos.swift
//  iHome
//
//  Created by Student07 on 06/11/23.
//

import SwiftUI

struct AdicionarServicos: View {
    @State private var selection = "Red"
       let colors = ["Red", "Green", "Blue", "Black", "Tartan"]

    var body: some View {
        ZStack{
            LinearGradient(gradient: Gradient(colors: [Color("azul"), Color("azul")]), startPoint: .top, endPoint: .center)
                .frame(width: .infinity, height: .infinity).ignoresSafeArea(.all)
            VStack{
                HStack{
                    Image("gabriel")
                    VStack{
                        VStack{
                            Text("Adicionar Serviços para Gabriel").font(.body).fontWeight(.black).foregroundColor(.white).multilineTextAlignment(.center)
 
                        }
                    }
                }
                VStack{
                    HStack{
                        Picker("Select a paint color", selection: $selection) {
                                      ForEach(colors, id: \.self) {
                                          Text($0)
                                      }
                                  }
                        
                        Picker("Select a paint color", selection: $selection) {
                                      ForEach(colors, id: \.self) {
                                          Text($0)
                                      }
                                  }
                    }

                                        
                    TextField("Valor", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/).frame(width: 300.0, height: 50.0).background(Color(#colorLiteral(red: 0.1, green: 0, blue: 1, alpha: 0.42))).foregroundColor(.white).cornerRadius(6)
                                        
                    TextField("Metodo", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/).frame(width: 300.0, height: 50.0).background(Color(#colorLiteral(red: 0.1, green: 0, blue: 1, alpha: 0.42))).foregroundColor(.white).cornerRadius(6)
                                        
                    LoginScreenButton(title: "Criar Serviço")
                        .padding(.top)
                    
                }
                .frame(width: 0.0)
                Spacer()
                
            
            }
        }
    }
}

struct AdicionarServicos_Previews: PreviewProvider {
    static var previews: some View {
        AdicionarServicos()
    }
}
