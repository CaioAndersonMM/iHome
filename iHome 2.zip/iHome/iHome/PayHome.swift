//
//  PayHome.swift
//  iHome
//
//  Created by Student07 on 30/10/23.
//

import SwiftUI

struct PayHome: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct PayHome_Previews: PreviewProvider {
    static var previews: some View {
        PayHome()
    }
}
