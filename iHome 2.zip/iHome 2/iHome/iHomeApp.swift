//
//  iHomeApp.swift
//  iHome
//
//  Created by Student07 on 30/10/23.
//

import SwiftUI

@main
struct iHomeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
