//
//  SolicitacoesHome.swift
//  iHome
//
//  Created by Student on 07/11/23.
//

import SwiftUI

struct SubcategorySolicitacion {
    var name: String
    var imageName: String
}

struct SolicitacoesHome: View {
    @State var servico = "Pinturas"
    @State var userAtualParaTeste = "UsuarioX"
    
    @State private var selection = ""
    
    let categories = ["Minhas Solicitações", "Meus Contratos"]
    

    @State var subcategories: [SubcategorySolicitacion] = [
        SubcategorySolicitacion(name: "Paredes", imageName: "pinturadeparede"),
        SubcategorySolicitacion(name: "Pisos", imageName: "pisos"),
        SubcategorySolicitacion(name: "Móveis", imageName: "moveis"),
        SubcategorySolicitacion(name: "Envernizar", imageName: "envernizamento"),
        SubcategorySolicitacion(name: "Grafites", imageName: "grafite")
    ]
    
    var body: some View {
        
        
        ZStack{
            LinearGradient(gradient: Gradient(colors: [Color("azul"), Color("azul")]), startPoint: .top, endPoint: .center)
                .frame(width: .infinity, height: .infinity).ignoresSafeArea(.all)
            VStack {
                Spacer()
                Text("Solicitações de Serviço de \(userAtualParaTeste)").font(.title3).fontWeight(.black).foregroundColor(.white).multilineTextAlignment(.center).padding([.top, .leading, .trailing], 20.0)
                
                HStack{
                    
                    Picker("Select a Category", selection: $selection) {
                        ForEach(categories, id: \.self) {
                            Text($0)
                        }
                    }.padding(.leading, 190.0).accentColor(.white)
                }


                ScrollView {
                    VStack{
                        ForEach(subcategories, id: \.name)  { sub in
                            VStack{
                                HStack(alignment: .top){
                                    Image("\(sub.imageName)").resizable().frame(width: 190.0, height: 130.0).scaledToFit()
                                    Spacer()
                                    VStack(alignment: .trailing){
                                        Text("\(sub.name)").font(.title3).fontWeight(.black).foregroundColor(Color("azul"))
                                        HStack{
                                            
                                            Image(systemName: "eye.fill").foregroundColor(Color("azul"))
                                            Text("\("Nome do Profissional")").font(.footnote).fontWeight(.black).foregroundColor(Color("azul")).multilineTextAlignment(.center).padding(/*@START_MENU_TOKEN@*/.vertical, 2.0/*@END_MENU_TOKEN@*/)
                                        }
                                       
                                        
                                        HStack{
                                            Text("R$ \(10000)").font(.footnote).fontWeight(.black).multilineTextAlignment(.leading).foregroundColor(.white).frame(width: 90.0, height: 20.0) .background(Color(red: 0x00/255, green: 0x3F/255, blue: 0x06/255).opacity(0.86)).cornerRadius(2)
                                            
                                            Text("\("Método")").font(.footnote).fontWeight(.black).multilineTextAlignment(.leading).foregroundColor(.white).frame(width: 90.0, height: 20.0)   .background(Color(red: 0x57/255, green: 0x3F/255, blue: 0x24/255)).cornerRadius(2)
                                            
                                        }.padding(.top)
                                        
                                        Spacer()
                                        
                                    }.padding(.trailing, 20.0).padding(.top, 7)
                                }
                                
                            }.background(.white).padding(.top, 2)
                            
                        }
                        .padding(.top)
                        
                    } //ForEach
                }
                
            }
            
        }
    }
    
}

struct SolicitacoesHome_Previews: PreviewProvider {
    static var previews: some View {
        SolicitacoesHome()
    }
}
