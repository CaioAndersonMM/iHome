//
//  APIViwelModel.swift
//  iHome
//
//  Created by Student on 30/10/23.
//

import Foundation

struct API : Decodable {
    var users: [User]
    var servicos: [Servico]?
    var avaliacoes: [AvaliacaoServico]?
    var userAtual: User?
}

struct Servico: Codable, Identifiable {
    var id: String?
    var _id: String?
    var idOferecedor: String?
    var idContratador: String?
    var tipo: String?
    var nome: String?
    var metodo: String?
    var descricao: String?
    var numeroDeServicos: Int?
    var preco: Float?
    var servicoPic: String?
}

struct AvaliacaoServico: Codable, Identifiable {
    var id: String?
    var _id: String?
    var idAvaliador: String?
    var idAvaliado: String?
    var estrelas: Int?
    var descricao: String?
    var data: String?
}

struct User : Codable, Identifiable {
    var id: String?
    var _id: String?
    var _rev: String?
    var nome: String?
    var sobrenome: String?
    var profilePic: String?
    var descricao: String?
    var email: String?
    var senha: String?
    var telefone: String?
    var mediaAvaliacoes: Int?
    var verificado: Bool?
    var numeroTotaldeAvaliacoes: Int?
}

class APIViewModel: ObservableObject {
    
    @Published var api = API(users: [User](), servicos: [Servico](), avaliacoes: [AvaliacaoServico](), userAtual: User())
    
    func fetchUsers() {
        guard let url = URL(string: "http://192.168.128.67:1880/getUsers/") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data , error == nil else {return}
            
            do {
                let decodificado = try JSONDecoder().decode([User].self, from: data)
                
                DispatchQueue.main.async {
                    //logica condicional aqui
                    self?.api.users = decodificado
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    func fetchUserAtualPorId(id: String) {
        guard let url = URL(string: "http://192.168.128.67:1880/getUser/?_id=\(id)") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data , error == nil else {return}
            
            do {
                let decodificado = try JSONDecoder().decode(User.self, from: data)
                
                DispatchQueue.main.async {
                    self?.api.userAtual = decodificado
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
    func postUser(usuario: User) {
        // Prepare URL
        let url = URL(string: "http://192.168.128.67:1880/postUser")
        guard let requestUrl = url else { fatalError() }
        
        // Prepare URL Request Object
        var request = URLRequest(url: requestUrl)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let jsonData = try? JSONEncoder().encode(usuario)
        request.httpBody = jsonData
        
        // Set HTTP Request Body
        print(jsonData!)
        
        // Perform HTTP Request
        let task = URLSession.shared.dataTask(with: request) { (jsonData, response, error) in
            if let error = error {
                print("Error took place \(error)")
                return
            }
        }
        task.resume()
    }
    
//    func postTeste(usuario: User, completion: @escaping (Result<User, Error>) -> Void) {
//        let urlString = "http://192.168.128.67:1880/postUser"
//        if let url = URL(string: urlString) {
//            var request = URLRequest(url: url)
//            request.httpMethod = "POST"
//            request.httpBody = try? JSONEncoder().encode(usuario)
//            request.addValue("application/json", forHTTPHeaderField: "Content-Type")
//
//            URLSession.shared.dataTask(with: request) { data, response, error in
//                if let error = error {
//                    completion(.failure(error))
//                    return
//                }
//                if let data = data {
//                    do {
//                        let decodedData = try JSONDecoder().decode(User.self, from: data)
//                        completion(.success(decodedData))
//                    } catch {
//                        completion(.failure(error))
//                    }
//                }
//            }.resume()
//        }
//    }
    
    func putUser(usuario: User){
        // Prepare URL
        let url = URL(string: "http://192.168.128.67:1880/putUser")
        guard let requestUrl = url else { fatalError() }
        
        // Prepare URL Request Object
        var request = URLRequest(url: requestUrl)
        request.httpMethod = "PUT"
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let jsonData = try? JSONEncoder().encode(usuario)
        request.httpBody = jsonData
        // Set HTTP Request Body
        print(jsonData!)
        
        // Perform HTTP Request
        let task = URLSession.shared.dataTask(with: request) { (jsonData, response, error) in
            if let error = error {
                print("Error took place \(error)")
                return
            }
        }
        task.resume()
    }
    
    func fetchUsers() {
        guard let url = URL(string: "http://192.168.128.67:1880/getServicos/") else {
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, _, error in
            guard let data = data , error == nil else {return}
            
            do {
                let decodificado = try JSONDecoder().decode([User].self, from: data)
                
                DispatchQueue.main.async {
                    self?.api.users = decodificado
                    
                }
            } catch {
                print(error)
            }
        }
        task.resume()
    }
    
}
