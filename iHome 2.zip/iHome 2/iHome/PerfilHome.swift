//
//  PerfilHome.swift
//  iHome
//
//  Created by Student07 on 30/10/23.
//

import SwiftUI

struct PerfilHome: View {
    @State var category = ""
    
    @State var subcategories: [SubcategoryConstrucao] = [
        SubcategoryConstrucao(name: "Alvenaria", imageName: "alvenaria"),
        SubcategoryConstrucao(name: "Torneiras", imageName: "torneira"),
        SubcategoryConstrucao(name: "Chuveiros", imageName: "chuveiro"),
        SubcategoryConstrucao(name: "Tomadas", imageName: "tomada"),
        SubcategoryConstrucao(name: "Ponto de Luz", imageName: "pontodeluz"),
        SubcategoryConstrucao(name: "Forros", imageName: "forro"),
        SubcategoryConstrucao(name: "Rebocos", imageName: "reboco"),
        SubcategoryConstrucao(name: "Ceramica", imageName: "ceramica"),
        SubcategoryConstrucao(name: "Portas", imageName: "porta"),
        SubcategoryConstrucao(name: "Estruturas Hidráulica", imageName: "encanamento"),
        SubcategoryConstrucao(name: "Estruturas Elétricas", imageName: "estruturaeletrica")
    ]
    
    var body: some View {
        NavigationStack{
            ZStack{
                LinearGradient(gradient: Gradient(colors: [Color("azul"), Color("azul")]), startPoint: .top, endPoint: .center)
                    .frame(width: .infinity, height: .infinity).ignoresSafeArea(.all)
                VStack(alignment: .leading){
                    HStack{
                        Image("gabriel")
                            .resizable()
                            .padding(.leading, 30.0)
                            .frame(width: 240.0, height: 210)
                        
                        VStack{
                            VStack{
                                Text("Alterar Foto Editar Nome").font(.footnote).fontWeight(.black).foregroundColor(Color("azul")).padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/).frame(width: 150.0).background(.white).cornerRadius(10)
                                
                                Text("Verificar Perfil").font(.footnote).fontWeight(.black).foregroundColor(Color("azul")).padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/).frame(width: 150.0).background(.white)
                                    .cornerRadius(10)
                                
                                NavigationLink(destination: Avaliacao()){
                                    
                                    Text("Ver Avaliações").font(.footnote).fontWeight(.black).foregroundColor(Color("azul")).padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/).frame(width: 150.0).background(.white)
                                        .cornerRadius(10)
                                }
                            }
                        }
                        
                    }
                    
                    VStack(alignment: .leading){
                        Text("Gabriel Calvao").font(.title).fontWeight(.black).foregroundColor(.white)
                        HStack{
                            HStack{
                                ForEach(1...4, id: \.self) { _ in
                                    Image(systemName: "star.fill")
                                        .foregroundColor(.yellow)
                                }
                                .padding(.vertical, 5.0)
                            } //Estrelas
                            Text("Serviços Ofertados").fontWeight(.black).foregroundColor(.white).padding(.leading, 60.0)
                        }
                        
                        ScrollView{
                            ForEach(subcategories, id: \.name) { item in
                                VStack{
                                    
                                    
                                    VStack{
                                        HStack(alignment: .top){
                                            Image(item.imageName).resizable().frame(width: 150.0, height: 140.0).scaledToFit()
                                            
                                            Spacer()
                                            
                                            VStack{
                                                Text(item.name).font(.footnote).fontWeight(.black).foregroundColor(Color("azul")).multilineTextAlignment(.leading).padding([.top, .leading, .bottom], 5.0)
                                                VStack{
                                                    ForEach(1...4, id: \.self) { _ in
                                                        Text("* Category").font(.caption).fontWeight(.bold).padding(.top, -5.0).foregroundColor(Color("azul"))
                                                    }
                                                    
                                                }
                                                
                                            }.padding(.trailing, 50.0)
                                            
                                            VStack{
                                                EditScreenButton(title: "Editar   ")
                                                    .padding(.top, 31.0)
                                                DeleteScreenButton(title: "Excluir")
                                            }
                                        }
                                    }.background(.white).padding(.top, 2)
                                    
                                }
                            }
                            NavigationLink(destination: AdicionarServicos()){
                                Text("Criar Novo Serviço")
                                    .multilineTextAlignment(.center)
                                    .frame(width: 190.0, height: 20.0)
                                    .padding()
                                    .background(Color(#colorLiteral(red: 0.2431372549, green: 0.4549019608, blue: 0.1450980392, alpha: 0.8)))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .shadow(radius: 5)
                                    .padding(.vertical, 10.0)
                                    .font(.title3)
                                    .fontWeight(.black)
                            }
                            
                        }
               
                    }
                    .padding(.leading)
                    
                    
                    
                }
                .padding(.leading, 20.0)
                
            }
        }
        
    }
}


struct EditScreenButton: View {
    var title: String
    
    var body: some View {
        HStack(alignment: .center) {
            Text(title)
                .font(.callout)
                .fontWeight(.bold)
        }
        .padding()
        .frame(height: 30.0)
        .background(Color(#colorLiteral(red: 0.0431372549, green: 0.1549019608, blue: 0.9450980392, alpha: 0.8)))
        .foregroundColor(.white)
        .cornerRadius(10)
        .shadow(radius: 5)
        .font(.caption2)
    }
}


struct DeleteScreenButton: View {
    var title: String
    
    var body: some View {
        HStack(alignment: .center) {
            Text(title)
                .font(.callout)
                .fontWeight(.bold)
        }
        .padding()
        .frame(height: 30.0)
        .background(Color(#colorLiteral(red: 0.7431372549, green: 0.1549019608, blue: 0.1450980392, alpha: 0.8)))
        .foregroundColor(.white)
        .cornerRadius(10)
        .shadow(radius: 5)
        .font(.caption2)
    }
}

struct PerfilHome_Previews: PreviewProvider {
    static var previews: some View {
        PerfilHome()
    }
}
